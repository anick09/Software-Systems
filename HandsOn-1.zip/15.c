//Anick Bhattacharya MT2022168
#include<stdio.h>
#include<unistd.h>

void main(void){
extern char **environ;
int i;
while(environ[i]){
printf("%s\n",environ[i++]);
}
}
