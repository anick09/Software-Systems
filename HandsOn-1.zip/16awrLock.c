#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
//Anick Bhattacharya MT2022168
void main(void){
int fd=open("test",O_WRONLY);
if(fd<0){printf("file not opened");return;}

struct flock lock={F_UNLCK,SEEK_SET,0,0,0};
int ret;
lock.l_type=F_WRLCK;

printf("Locking test file\n");

ret=fcntl(fd,F_SETLKW,&lock);

printf("file writelocked %d \nPress enter to unlock\n",ret);

if(ret<0)
perror("Not locked");

getchar();

lock.l_type=F_UNLCK;
ret=fcntl(fd,F_SETLKW,&lock);
printf("Released lock\n");

getchar();
}
