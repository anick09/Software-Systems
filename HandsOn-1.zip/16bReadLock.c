#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
//Anick Bhattacharya MT2022168
void main(void){
int fd=open("test",O_RDWR);
if(fd<0){printf("file not opened\n");return;}
int ret;
struct flock fl={F_UNLCK,SEEK_SET,0,0,0};
printf("locking in readlock\n");
fl.l_type=F_RDLCK;

ret=fcntl(fd,F_SETLKW,&fl);
if(ret<0) perror("Error");
else printf("File Readlocked\nPress enter to unlock\n"); 
getchar();

fl.l_type=F_UNLCK;
fcntl(fd,F_SETLKW,&fl);

printf("Lock Released\n");

}
