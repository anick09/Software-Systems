//Anick Bhattacharya MT2022168
#include<stdio.h>
#include<fcntl.h>
#include<sys/types.h>
#include<unistd.h>
struct ticket{
	int num;
	int id;
};

void main(){
	struct ticket db;
	int fd=open("ticket_db.txt",O_RDWR | O_CREAT);
	
	db.num=1;
	db.id=1;
	write(fd,&db,sizeof(db));
	
	close(fd);	
}
