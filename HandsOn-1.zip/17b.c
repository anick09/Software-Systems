//Anick Bhattacharya MT2022168
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>

void main(void){
struct ticket{
	int num;
	int id;
}db,db2;

int fd=open("ticket_db.txt",O_RDWR);
struct flock lock={F_WRLCK,SEEK_SET,0,0,0};

int ret=fcntl(fd,F_SETLK,&lock);

read(fd,&db,sizeof(db));
printf("%d\n",db.num);
printf("%d\n",db.id);

int newtck=db.num+1;
db2.num=newtck;
db2.id=db.id+1;

write(fd,&db2,sizeof(db2));

lock.l_type=F_UNLCK;
ret=fcntl(fd,F_SETLK,&lock);

close(fd);
}
