//Anick Bhattacharya MT2022168
int main(void){
printf("%d",getpid());
while(1) getchar();
//printf("%d",getpid());
}
