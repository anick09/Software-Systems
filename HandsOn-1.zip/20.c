//Anick Bhattacharya MT2022168
#include<stdio.h>
#include<unistd.h>
void main(){
printf("%ld\n",getpid());
while(1);
}
