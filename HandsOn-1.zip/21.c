#include<stdio.h>
#include<sys/types.h>

void main(void){
//Anick Bhattacharya  MT2022168
int pid=fork();

if(pid==0)
{
printf("Child process id:%d\n",getpid());
}
else{
printf("Parent Process id:%d\n",getpid());
}

//printf("hello\n");

}
