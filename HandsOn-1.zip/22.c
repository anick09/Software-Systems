#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<fcntl.h>
//Anick Bhattacharya MT2022168
void main(void ){
int fd=open("source",O_RDWR);
char buff1[]="This is from Child";
char buff2[]="This is from parent";
char ch='\n';
if(fd<0){
printf("file not opened\n");
return ;
}

int pid=fork();

if(pid==0){
printf("From Child Process fd=%d\n",fd);
write(fd,&buff1,sizeof(buff1));
write(fd,&ch,1);
}
else
{
wait(0);
printf("From parent Process\n");
write(fd,&buff2,sizeof(buff2));
write(fd,&ch,1);
}

}
