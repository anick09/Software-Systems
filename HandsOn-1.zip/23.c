#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>

//Anick Bhattacharya MT2022168

void main(void){
	pid_t pid = fork();
	
	if(pid>0){
		printf("Parent process id = %d",getpid());
		sleep(20);
	}
	else{
		printf("Child process id = %d",getpid()); 
		sleep(10);

	}
}
