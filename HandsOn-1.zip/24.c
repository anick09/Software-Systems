#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
//Anick Bhattacharya MT2022168
void main(void){
	pid_t pid;
	pid=fork();
	
	if(pid>0){
		printf("Parent Process\n");
		//sleep(5);	
	}
	else{
		printf("Child Process\n");
		sleep(30);
	}
}
