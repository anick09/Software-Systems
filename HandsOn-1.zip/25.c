#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
//Anick Bhattacharya MT2022168
void main(void){
	pid_t pid=fork();
	pid_t pid2,pid3;
	
	if(pid)
	{
		pid2=fork();
		
		if(pid2)
		{
			pid3=fork();
		
			if(pid3==0)
			{
				sleep(10);
				printf("Child 3 dies %d\n",getpid());
			}
			
			else
			{
				waitpid(pid2);
				printf("Parent process mar gaya%d\n",getpid());
			}
					
		}
		else
		{
			sleep(5);
			printf("Child 2 dies %d\n",getpid());
		}
	}
	else
	{
		printf("Child 1 dies %d\n",getpid());
	}
	
}
