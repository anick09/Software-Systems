#include<stdio.h>
#include<unistd.h>
//Anick Bhattacharya MT2022168
void main(void){
execl("26source.out","","Passed from EXECl\n",NULL);
}
