//Anick Bhattacharya MT2022168
#include<stdio.h>
int main(int n,char *argc[]){
printf("%s",argc[1]);
return 1;
}
