#include<unistd.h>
//Anick Bhattacharya MT2022168
int main(){
	char *file="ls";
	char *arg="-a";
	execlp(file,file,arg,NULL);
	return 0;
}
