#include<stdio.h>
#include<unistd.h>
//Anick Bhattacharya MT2022168
int main(void){
char *path = "/bin/ls";
char *arg="-l";
execl(path,"",arg,NULL);
return 0;
}
