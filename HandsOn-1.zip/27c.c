#include <unistd.h>
 //Anick Bhattacharya MT2022168
int main(void) {
  char *binaryPath = "/bin/bash";
  char *arg1 = "-c";
  char *arg2 = "echo \"Visit $hostname:$PORT from browser\"";
  char *const env[] = {"hostname=www.google.com", "PORT=8080", NULL};
 
  execle(binaryPath, binaryPath,arg1, arg2, NULL, env);
 
  return 0;
}
