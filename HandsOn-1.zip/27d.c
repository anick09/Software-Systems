//Anick Bhattacharya MT2022168
#include<unistd.h>
int main(void)
{
char *bin_path="/bin/ls";
char *args[]={bin_path,"-a",NULL};
execv(bin_path,args);
return 0;
}

