//Anick Bhattacharya MT2022168
#include<unistd.h>
int main(void)
{
char *bin_path="ls";
char *args[]={bin_path,"-a",NULL};
execvp(bin_path,args);
return 0;
}

