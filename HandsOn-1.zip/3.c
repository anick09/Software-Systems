//Anick Bhattacharya MT2022168
#include<stdio.h>
void main(void){
int fd=creat("Test.txt",0744);
printf("File descriptor=%d\n",fd);
}
