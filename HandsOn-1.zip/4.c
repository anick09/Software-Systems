//Anick Bhattacharya MT2022168
#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>

void main(){
int fd=open("Test.txt",O_EXCL);
printf("Opened file: %d\n",fd);
}
