//Anick Bhattacharya MT2022168
#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>

void main(){
char b[30];
read(0,b,5);
write(1,b,5);
}
