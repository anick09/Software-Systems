//Anick Bhattacharya MT2022168
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>

void main(void){

char buff1;

int fd1=open("source",O_RDWR);
int fd2=open("dest",O_RDWR);

while(read(fd1,&buff1,sizeof(char))){
write(fd2,&buff1,sizeof(char));
}

//read(fd1,buff1,sizeof(buff1));
//write(fd2,buff1,sizeof(buff1));
close(fd1);
close(fd2);
}
