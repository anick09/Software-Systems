//Anick Bhattacharya MT2022168
#include<stdio.h>
void main(void){
printf("Executable file for 26\n");
}
