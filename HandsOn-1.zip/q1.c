//Anick Bhattacharya MT2022168
#include<stdio.h>
void main(void){
if(!link("source","hardlink_systemcall")){
printf("Hardlink created successfully\n");
}

if(!symlink("source","softlink_systemcall")){
printf("Softlink created sucessfully\n");
}
}
