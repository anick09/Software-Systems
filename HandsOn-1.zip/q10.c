#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
//Anick Bhattacharya MT2022168
void main(void){
	int fd=open("file",O_RDWR);
	char s[10];
	printf("Enter 10 bytes data\n");
	scanf("%s",&s);

	write(fd,&s,sizeof(s));

	/*printf("Printing file data\n");
	char ch;
	while(read(fd,&ch,sizeof(ch))){
		printf("%c",ch);
	}*/
	int value=lseek(fd,10,SEEK_CUR);
	printf("Return of Seek:%d\n",value);
	printf("Entering 10 bytes\n");
	write(fd,&s,sizeof(s));
}
