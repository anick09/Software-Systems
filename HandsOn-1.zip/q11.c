#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
//Anick Bhattacharya MT2022168
void main(void){
int fd=open("file",O_RDWR);

printf("enter data to append\n");
char ch[20];
scanf("%s",&ch);
lseek(fd,0,SEEK_END);
int newfd=dup(fd);
printf("using dup\n");
write(newfd,&ch,sizeof(ch));

printf("Using dup2\n");
int newfd2=5;
dup2(fd,newfd2);
write(newfd2,&ch,sizeof(ch));

printf("%d %d %d",fd,newfd,newfd2);
}
