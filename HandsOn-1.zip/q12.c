//Anick Bhattacharya MT2022168
#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>

void main(void){
int fd=open("file",O_RDWR);
if(fd<0){
 printf("file not opened\n");
return ;
}

int filemode=fcntl(fd, F_GETFL);
printf("FileMode: %d ",filemode);
}
