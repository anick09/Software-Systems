#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/types.h>
//Anick Bhattacharya MT2022168
void main(void){

fd_set fd;
FD_ZERO(&fd);
FD_SET(0,&fd);
//int fd=0;

struct timeval tv;
tv.tv_sec=10;
tv.tv_usec=0;

int ret=select(1,&fd,NULL,NULL,&tv);


if(ret){
printf("Data available\n");
}

else{
printf("Data not available within 10 sec\n");
}
}
