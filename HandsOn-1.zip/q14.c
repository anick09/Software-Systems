//Anick Bhattacharya MT2022168
#include<sys/types.h>
#include<sys/stat.h>
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>

int main(int argc, char** path)
{
	struct stat sb;
	int ret =  stat(path[1], &sb);
	
	if(ret==-1){
		perror("Error: ");
		return  0;
	}
	
	printf("%s\n", path[1]);
	printf("File type:	");

	switch (sb.st_mode) {
		case S_IFBLK:  printf("block device\n");            break;
		case S_IFCHR:  printf("character device\n");        break;
		case S_IFDIR:  printf("directory\n");               break;
		case S_IFIFO:  printf("FIFO/pipe\n");               break;
		case S_IFLNK:  printf("symlink\n");                 break;
		case S_IFREG:  printf("regular file\n");            break;
		case S_IFSOCK: printf("socket\n");                  break;
		default:       printf("unknown?\n");                break;
	}

	return 0;
}
