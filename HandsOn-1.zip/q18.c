//Anick Bhattacharya MT2022168
#include<stdio.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<unistd.h>

void main(){
	struct tkt_db{
		int tkno;
		int usrid;
	}db, db2;
	int userid,	 retval;
	int fd = open("ticket_db.txt", O_RDWR);
	
	printf("Enter user ID to book Ticket : ");
	scanf("%d", &userid);

	
	struct flock lck;
		lckdb.l_type = F_WRLCK;
		lckdb.l_whence = SEEK_END; 
		lckdb.l_start = -sizeof(db); 
		lckdb.l_len = 0;
		lckdb.l_pid = getpid();

	fcntl(fd, F_SETLK, &lck);
	

	while( read(fd, &db, sizeof(db)) );

	db2.tkno = db.tkno + 1; 
	db2.usrid = userid;
	
	lckdb.l_type = F_UNLCK; 
	fcntl(fd, F_SETLK, &lck);

	lckdb.l_type = F_WRLCK;
	lckdb.l_whence = SEEK_END; 
	lckdb.l_start = sizeof(db); 
	lckdb.l_len = 0;
	lckdb.l_pid = getpid();

	fcntl(fd, F_SETLK, &lck);


	if(write(fd, &db2, sizeof(db2))>0) 
		printf("\nAlloted Ticket Number: %d\n", db.tkno);
	
	lckdb.l_type = F_UNLCK; 
	fcntl(fd, F_SETLK, &lck);

	perror("Status: ");
	

	close(fd);
}
