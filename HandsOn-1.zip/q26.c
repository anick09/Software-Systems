//Anick Bhattacharya MT2022168
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>

void main(void){
	execl("a.out","",NULL,NULL);
}
