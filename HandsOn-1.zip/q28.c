//Anick Bhattacharya MT2022168

#include <sched.h> 
#include <stdio.h> 

void main()
{
    int maxPriority, minPriority;

    maxPriority = sched_get_priority_max(SCHED_RR);
    if (maxPriority == -1)
        perror("Error\n");
    else
        printf("The max priority with Round Robin : %d\n", maxPriority);

    minPriority = sched_get_priority_min(SCHED_RR);
    if (minPriority == -1)
        perror("Error\n");
    else
        printf("The min priority with Round Robin : %d\n", minPriority);
}
