//Anick Bhattacharya MT2022168
#include <sched.h> 
#include <sys/types.h> 
#include <unistd.h>    
#include <stdio.h>     

void main()
{
    int currentPolicy;
    pid_t pid;
    pid = getpid();
    currentPolicy = sched_getscheduler(pid);
    struct sched_param priority;
    
    priority.sched_priority = 10;

    switch (currentPolicy)
    {
    case SCHED_FIFO:
        printf("Current policy is FIFO\n");
        sched_setscheduler(pid, SCHED_RR, &priority);
        currentPolicy = sched_getscheduler(pid);
        printf("Current policy: %d\n", currentPolicy);
        break;
    case SCHED_RR:
        printf("Current policy is Round Robin\n");
        sched_setscheduler(pid, SCHED_FIFO, &priority);
        currentPolicy = sched_getscheduler(pid);
        printf("Current policy: %d\n", currentPolicy);
        break;
    case SCHED_OTHER:
        printf("Current policy is other\n");
        sched_setscheduler(pid, SCHED_RR, &priority);
        currentPolicy = sched_getscheduler(pid);
        printf("Current policy: %d\n", currentPolicy);
        break;
    default:
        perror("Error\n");
    }
}


