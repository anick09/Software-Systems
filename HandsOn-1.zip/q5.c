//Anick Bhattacharya MT2022168
#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>

void main(void){
int fd[5];
fd[0]=creat("Test1.txt",0743);
fd[1]=creat("Test2.txt",0743);
fd[2]=creat("Test3.txt",0743);
fd[3]=creat("Test4.txt",0743);
fd[4]=creat("Test5.txt",0743);
getchar();
}
