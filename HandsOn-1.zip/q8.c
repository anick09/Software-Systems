//Anick Bhattacharya MT2022168
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>

void main(void){
int fd=open("source",O_RDONLY);
char ch;
char b[30];int c=0;
while(read(fd,&ch,sizeof(char))){
	if(ch=='\n'){
		write(1,&b,c);
		c=0;
		printf("\n");
		}

	else{
	b[c]=ch;
	c++;
	}
}
}

