//Anick Bhattacharya MT2022168
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<sys/types.h>

void main(void){
	int fd=open("source",O_RDWR);
	//printf("%d\n",fd);
	struct stat filestat;
	int x = fstat(fd,&filestat);
	//printf("%d\n",x);
	
	printf("Inode No:%ld\n",filestat.st_ino);
	printf("No. of Hardlinks:%ld\n",filestat.st_nlink);
	printf("uid:%ld\n",filestat.st_uid);
	printf("gid:%ld\n",filestat.st_gid);
	printf("size:%ld\n",filestat.st_size);
	printf("block size:%ld\n",filestat.st_blksize);
	printf("number of blocks:%ld\n",filestat.st_blocks);
	printf("time of last access:%ld\n",filestat.st_atim);
	printf("time of last modification:%ld\n",filestat.st_mtim);
	printf("time of last change:%ld\n",filestat.st_ctim);	
}
